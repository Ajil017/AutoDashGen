// AutoDashGen Power Query (M) Script for uncleaned bike sales data.xlsx

let
    Source = Csv.Document(File.Contents("YOUR_PATH_TO\uncleaned bike sales data.xlsx"),[Delimiter=",", Columns=19, Encoding=1252, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{ {"Sales_Order #", Int64.Type},
        {"Date", type datetime},
        {"Day", type number},
        {"Month", type text},
        {"Year", Int64.Type},
        {"Customer_Age", Int64.Type},
        {"Age_Group", type text},
        {"Customer_Gender", type text},
        {"Country", type text},
        {"State", type text},
        {"Product_Category", type text},
        {"Sub_Category", type text},
        {"Product_Description", type text},
        {"Order_Quantity", type number},
        {" Unit_Cost ", Int64.Type},
        {" Unit_Price ", Int64.Type},
        {" Profit ", Int64.Type},
        {" Cost ", Int64.Type},
        {"Revenue", Int64.Type} })
in
    #"Changed Type"